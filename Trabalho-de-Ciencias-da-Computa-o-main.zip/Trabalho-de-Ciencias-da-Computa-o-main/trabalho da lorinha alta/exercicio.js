function Tarefa3(){
    const notas = parseInt(prompt("Digite Quantas Notas: "));
    let somaN = 0;

    for (let i = 1; i <= notas; i++){
        const notat = parseFloat(prompt(`Digite sua nota ${i}`));
        somaN += notat;
    }

const media = somaN / notas;
alert(`A média das ${notas} notas é: ${media}`);

}

function numero(num) {
    
    if (num <= 1) return false;
    if (num <= 3) return true;
    if (num % 2 === 0 || num % 3 === 0) return false;

    for (let i = 5; i * i <= num; i += 6) {
        if (num % i === 0 || num % (i + 2) === 0) return false;
    }

    return true;
}

function Tarefa4() {
    const input = prompt("Digite um número para verificar se é primo:");
    const number = parseInt(input, 10);

    if (isNaN(number) || number <= 1) {
        alert("Por favor, insira um número maior que 1.");
        return;
    }

    if (numero(number)) {
        alert("É um numero primo");
    } else {
        alert("Não é um numero primo");
    }
}

checkPrime();